This directory contains local copies of W3C (www.w3c.org) XHTML DTDs for use by the Ant xmlvalidate task.
